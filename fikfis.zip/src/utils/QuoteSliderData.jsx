export const SliderData = [
    { name: "Export @fikfis, we are poised to deliver best quality" },
    { name: "Export @fikfis, we are poised to deliver best quality" },
    { name: "Export @fikfis, we are poised to deliver best quality" },
    { name: "Export @fikfis, we are poised to deliver best quality" },
    { name: "Export @fikfis, we are poised to deliver best quality" }
]