export const BlogsList = [
    { id: 1, name: "Loreum Ipsum", images: "/images/blogs/blog1.svg", heading:"What is Lorem Ipsum?", description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of", date: '06 July 2023', author: 'FikFis', detailQuote: "“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard“" },
    { id: 2, name: "Loreum Ipsum", images: "/images/blogs/blog2.svg", heading:"What is Lorem Ipsum?", description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of", date: '06 July 2023', author: 'FikFis', detailQuote: "“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard“" },
    { id: 3, name: "Loreum Ipsum", images: "/images/blogs/blog3.svg", heading:"What is Lorem Ipsum?", description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of", date: '06 July 2023', author: 'FikFis', detailQuote: "“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard“" },
    { id: 4, name: "Loreum Ipsum", images: "/images/blogs/blog4.svg", heading:"What is Lorem Ipsum?", description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of", date: '06 July 2023', author: 'FikFis', detailQuote: "“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard“" },
    { id: 5, name: "Loreum Ipsum", images: "/images/blogs/blog5.svg", heading:"What is Lorem Ipsum?", description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of", date: '06 July 2023', author: 'FikFis', detailQuote: "“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard“" },
    { id: 6, name: "Loreum Ipsum", images: "/images/blogs/blog6.svg", heading:"What is Lorem Ipsum?", description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of", date: '06 July 2023', author: 'FikFis', detailQuote: "“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard“" },
];

export const BlogCategoryList = [
    { 
        id: 1, 
        name: 'Electronics', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 2, 
        name: 'Fashion', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 3, 
        name: 'Home Kitchen', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 4, 
        name: 'Beauty & Personal Care', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 5, 
        name: 'Sports & Outdoors', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 6, 
        name: 'Toys & Games', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 7, 
        name: 'Automotive', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 8, 
        name: 'Book & Media', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 9, 
        name: 'Health & Wellness', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 10, 
        name: 'Groceries & Gourmet Fooda', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 11, 
        name: 'Mobile Phones', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 12, 
        name: 'Laptops', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 13, 
        name: 'Tablets', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 14, 
        name: 'Cameras', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 15, 
        name: 'Accessories', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    },
    { 
        id: 16, 
        name: 'Men"s Clothing', 
        subcategory: [
            { id: 's1', name: 'Furniture' },
            { id: 's2', name: 'Home Decor' },
            { id: 's3', name: 'Kitchen Appliances' },
            { id: 's4', name: 'Cookware' },
            { id: 's5', name: 'Bedding' },
        ]
    }
]