export const BannerOfferData = [
    { 
        title: 'Mega Sale', 
        price: 'Under $99', 
        type: 'Bedsheet, Blankets & pillows', 
        delivery: 'Free delivery, 10 Days returns' 
    }
]