export const faqList = [
  {
    id: 1,
    name: "What is Faq?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 2,
    name: "What are your shipping options?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 3,
    name: "How do I create an account?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 4,
    name: "Can I modify or cancel my order after placing it?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 5,
    name: "How do I place an order?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 6,
    name: "How long does it take to process a refund?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 7,
    name: "How can I contact customer support?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 8,
    name: "What if an item is out of stock?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 9,
    name: "Are the products on your site authentic?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 10,
    name: "How do I reset my password?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
  {
    id: 11,
    name: "Do I need an account to place an order?",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of",
  },
];

export const mainFilter = [
  { id: 1, name: "Category", description: "" },
  { id: 2, name: "Size", description: "" },
  { id: 3, name: "Category", description: "" },
  { id: 4, name: "Category", description: "" },
  { id: 5, name: "Category", description: "" },
];

export const mainProductFilterList = [
  {
    id: 1,
    name: "Electronics",
    subProduct: [
      {
        id: 101,
        name: "Washing Machine",
        innerProduct: [
          { id: 1011, name: "LG" },
          { id: 1012, name: "Hitachi" },
          { id: 1013, name: "Carrier" },
        ],
      },
      {
        id: 102,
        name: "Air Conditioners",
        innerProduct: [
          { id: 1021, name: "LG" },
          { id: 1022, name: "Hitachi" },
          { id: 1023, name: "Carrier" },
        ],
      },
      {
        id: 103,
        name: "Shop By Brands",
        innerProduct: [
          { id: 1031, name: "LG" },
          { id: 1032, name: "Hitachi" },
          { id: 1033, name: "Carrier" },
        ],
      },
      {
        id: 104,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 1041, name: "LG" },
          { id: 1042, name: "Hitachi" },
          { id: 1043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 2,
    name: "Tv & Appliances",
    subProduct: [
      {
        id: 201,
        name: "Washing Machine",
        innerProduct: [
          { id: 2011, name: "LG" },
          { id: 2012, name: "Hitachi" },
          { id: 2013, name: "Carrier" },
        ],
      },
      {
        id: 202,
        name: "Air Conditioners",
        innerProduct: [
          { id: 2021, name: "LG" },
          { id: 2022, name: "Hitachi" },
          { id: 2023, name: "Carrier" },
        ],
      },
      {
        id: 203,
        name: "Shop By Brands",
        innerProduct: [
          { id: 2031, name: "LG" },
          { id: 2032, name: "Hitachi" },
          { id: 2033, name: "Carrier" },
        ],
      },
      {
        id: 204,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 2041, name: "LG" },
          { id: 2042, name: "Hitachi" },
          { id: 2043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 3,
    name: "Men",
    subProduct: [
      {
        id: 301,
        name: "Washing Machine",
        innerProduct: [
          { id: 3011, name: "LG" },
          { id: 3012, name: "Hitachi" },
          { id: 3013, name: "Carrier" },
        ],
      },
      {
        id: 302,
        name: "Air Conditioners",
        innerProduct: [
          { id: 3021, name: "LG" },
          { id: 3022, name: "Hitachi" },
          { id: 3023, name: "Carrier" },
        ],
      },
      {
        id: 303,
        name: "Shop By Brands",
        innerProduct: [
          { id: 3031, name: "LG" },
          { id: 3032, name: "Hitachi" },
          { id: 3033, name: "Carrier" },
        ],
      },
      {
        id: 304,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 3041, name: "LG" },
          { id: 3042, name: "Hitachi" },
          { id: 3043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 4,
    name: "Women",
    subProduct: [
      {
        id: 401,
        name: "Washing Machine",
        innerProduct: [
          { id: 4011, name: "LG" },
          { id: 4012, name: "Hitachi" },
          { id: 4013, name: "Carrier" },
        ],
      },
      {
        id: 402,
        name: "Air Conditioners",
        innerProduct: [
          { id: 4021, name: "LG" },
          { id: 4022, name: "Hitachi" },
          { id: 4023, name: "Carrier" },
        ],
      },
      {
        id: 403,
        name: "Shop By Brands",
        innerProduct: [
          { id: 4031, name: "LG" },
          { id: 4032, name: "Hitachi" },
          { id: 4033, name: "Carrier" },
        ],
      },
      {
        id: 404,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 4041, name: "LG" },
          { id: 4042, name: "Hitachi" },
          { id: 4043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 5,
    name: "Baby & Kids",
    subProduct: [
      {
        id: 501,
        name: "Washing Machine",
        innerProduct: [
          { id: 5011, name: "LG" },
          { id: 5012, name: "Hitachi" },
          { id: 5013, name: "Carrier" },
        ],
      },
      {
        id: 502,
        name: "Air Conditioners",
        innerProduct: [
          { id: 5021, name: "LG" },
          { id: 5022, name: "Hitachi" },
          { id: 5023, name: "Carrier" },
        ],
      },
      {
        id: 503,
        name: "Shop By Brands",
        innerProduct: [
          { id: 5031, name: "LG" },
          { id: 5032, name: "Hitachi" },
          { id: 5033, name: "Carrier" },
        ],
      },
      {
        id: 504,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 5041, name: "LG" },
          { id: 5042, name: "Hitachi" },
          { id: 5043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 6,
    name: "Kitchen Appliances",
    subProduct: [
      {
        id: 601,
        name: "Washing Machine",
        innerProduct: [
          { id: 6011, name: "LG" },
          { id: 6012, name: "Hitachi" },
          { id: 6013, name: "Carrier" },
        ],
      },
      {
        id: 602,
        name: "Air Conditioners",
        innerProduct: [
          { id: 6021, name: "LG" },
          { id: 6022, name: "Hitachi" },
          { id: 6023, name: "Carrier" },
        ],
      },
      {
        id: 603,
        name: "Shop By Brands",
        innerProduct: [
          { id: 6031, name: "LG" },
          { id: 6032, name: "Hitachi" },
          { id: 6033, name: "Carrier" },
        ],
      },
      {
        id: 604,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 6041, name: "LG" },
          { id: 6042, name: "Hitachi" },
          { id: 6043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 7,
    name: "Home Decor",
    subProduct: [
      {
        id: 701,
        name: "Washing Machine",
        innerProduct: [
          { id: 7011, name: "LG" },
          { id: 7012, name: "Hitachi" },
          { id: 7013, name: "Carrier" },
        ],
      },
      {
        id: 702,
        name: "Air Conditioners",
        innerProduct: [
          { id: 7021, name: "LG" },
          { id: 7022, name: "Hitachi" },
          { id: 7023, name: "Carrier" },
        ],
      },
      {
        id: 703,
        name: "Shop By Brands",
        innerProduct: [
          { id: 7031, name: "LG" },
          { id: 7032, name: "Hitachi" },
          { id: 7033, name: "Carrier" },
        ],
      },
      {
        id: 704,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 7041, name: "LG" },
          { id: 7042, name: "Hitachi" },
          { id: 7043, name: "Carrier" },
        ],
      },
    ],
  },
  {
    id: 8,
    name: "Automobile",
    subProduct: [
      {
        id: 801,
        name: "Washing Machine",
        innerProduct: [
          { id: 8011, name: "LG" },
          { id: 8012, name: "Hitachi" },
          { id: 8013, name: "Carrier" },
        ],
      },
      {
        id: 802,
        name: "Air Conditioners",
        innerProduct: [
          { id: 8021, name: "LG" },
          { id: 8022, name: "Hitachi" },
          { id: 8023, name: "Carrier" },
        ],
      },
      {
        id: 803,
        name: "Shop By Brands",
        innerProduct: [
          { id: 8031, name: "LG" },
          { id: 8032, name: "Hitachi" },
          { id: 8033, name: "Carrier" },
        ],
      },
      {
        id: 804,
        name: "Kitchen Appliances",
        innerProduct: [
          { id: 8041, name: "LG" },
          { id: 8042, name: "Hitachi" },
          { id: 8043, name: "Carrier" },
        ],
      },
    ],
  },
];

export const sizeOptions = [
  { id: 1, label: "L (8/10)" },
  { id: 2, label: "xxs (0)" },
  { id: 3, label: "L (12/14)" },
  { id: 4, label: "XS (2)" },
  { id: 5, label: "XL (16/18)" },
  { id: 6, label: "S (8)" },
  { id: 7, label: "XL (12)" },
  { id: 8, label: "S (4/6)" },
  { id: 9, label: "XL (8)" },
  { id: 10, label: "S (5)" },
  { id: 11, label: "XS" },
  { id: 12, label: "M(10)" },
  { id: 13, label: "s" },
  { id: 14, label: "M(6)" },
  { id: 15, label: "m" },
  { id: 16, label: "M(8/10)" },
  { id: 17, label: "l" },
  { id: 18, label: "L(12)" },
  { id: 19, label: "xl" },
  { id: 20, label: "L(7)" },
  { id: 21, label: "XXL" },
];

export const priceOptions = [
  { id: "p1", label: "Under $12" },
  { id: "p2", label: "$12 - $185" },
  { id: "p3", label: "$185 - $333" },
  { id: "p4", label: "Over $333" },
];

export const ratingOptions = [
  { id: "c1", label: "4★ & above" },
  { id: "c2", label: "3★ & above" },
  { id: "c3", label: "2★ & above" },
  { id: "c4", label: "1★ & above" },
];

export const colors = [
  "/images/color-palette/color1.svg",
  "/images/color-palette/color2.svg",
  "/images/color-palette/color3.svg",
  "/images/color-palette/color4.svg",
  "/images/color-palette/color5.svg",
  "/images/color-palette/color6.svg",
  "/images/color-palette/color7.svg",
  "/images/color-palette/color8.svg",
  "/images/color-palette/color9.svg",
  "/images/color-palette/color10.svg",
  "/images/color-palette/color11.svg",
  "/images/color-palette/color12.svg",
  "/images/color-palette/color13.svg",
  "/images/color-palette/color14.svg",
  "/images/color-palette/color15.svg",
  "/images/color-palette/color16.svg",
  "/images/color-palette/color17.svg",
  "/images/color-palette/color18.svg",
  "/images/color-palette/color19.svg",
  "/images/color-palette/color20.svg",
  "/images/color-palette/color21.svg",
  "/images/color-palette/color22.svg",
  "/images/color-palette/color23.svg",
  "/images/color-palette/color24.svg",
  "/images/color-palette/color25.svg",
  "/images/color-palette/color26.svg",
  "/images/color-palette/color27.svg",
  "/images/color-palette/color28.svg",
];

export const paymentOptions = [
  { id: "1", label: "Cash On Delivery" },
  { id: "2", label: "Pay Online" },
];

export const User = {
  id: 1,
  name: "John Goige",
  email: "jhongoige@gmail.com",
  phone: "+448956231245",
  password: "12345678",
  image: "/images/profile/user.svg",
  activeOrders: [
    {
      id: 1,
      image: "/images/product/img-16.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "4",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      tracking_id: "XDYUS000058",
      total: "£10,000 ",
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: false,
          done: false,
        },
        {
          id: 4,
          message: "Delivered",
          track_time: "Friday 9th July 12:30 pm",
          started: false,
          done: false,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discountlabel: "",
      time: "",
      discount: "105100",
      original: "1790.00",
      save: "save $5",
      coupen: "with coupen",
      deliverytime: "Tuesday, Jul 16 – Saturday, Jul 20",
      freedelivery: "Free Delivery",
      bestseller: false,
      small: [
        { id: 100, image: "/images/product/img-16.svg" },
        { id: 101, image: "/images/product/small1.svg" },
        { id: 102, image: "/images/product/small2.svg" },
        { id: 103, image: "/images/product/small3.svg" },
        { id: 104, image: "/images/product/small4.svg" },
        { id: 105, image: "/images/product/small5.svg" },
        { id: 106, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
    {
      id: 2,
      image: "/images/product/img-13.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "3",
      discountlabel: "",
      time: "",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      tracking_id: "XDYUS000058",
      total: "£10,000 ",
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: false,
        },
        {
          id: 4,
          message: "Delivered",
          track_time: "Friday 9th July 12:30 pm",
          started: false,
          done: false,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discount: "105100",
      original: "1790.00",
      save: "",
      coupen: "",
      deliverytime: "Get it by Sunday, June 16",
      freedelivery: "FREE Delivery over $499.",
      bestseller: false,
      small: [
        { id: 200, image: "/images/product/img-13.svg" },
        { id: 201, image: "/images/product/small1.svg" },
        { id: 202, image: "/images/product/small2.svg" },
        { id: 203, image: "/images/product/small3.svg" },
        { id: 204, image: "/images/product/small4.svg" },
        { id: 205, image: "/images/product/small5.svg" },
        { id: 206, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
  ],
  deliveredOrders: [
    {
      id: 1,
      image: "/images/product/img-16.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "4",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      order_status: "Delivered",
      total: "£10,000 ",
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 4,
          message: "Delivered",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: true,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discountlabel: "",
      time: "",
      discount: "105100",
      original: "1790.00",
      save: "save $5",
      coupen: "with coupen",
      deliverytime: "Tuesday, Jul 16 – Saturday, Jul 20",
      freedelivery: "Free Delivery",
      bestseller: false,
      small: [
        { id: 100, image: "/images/product/img-16.svg" },
        { id: 101, image: "/images/product/small1.svg" },
        { id: 102, image: "/images/product/small2.svg" },
        { id: 103, image: "/images/product/small3.svg" },
        { id: 104, image: "/images/product/small4.svg" },
        { id: 105, image: "/images/product/small5.svg" },
        { id: 106, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
    {
      id: 2,
      image: "/images/product/img-13.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "3",
      discountlabel: "",
      time: "",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      order_status: "Delivered",
      total: "£10,000 ",
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 4,
          message: "Delivered",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: true,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discount: "105100",
      original: "1790.00",
      save: "",
      coupen: "",
      deliverytime: "Get it by Sunday, June 16",
      freedelivery: "FREE Delivery over $499.",
      bestseller: false,
      small: [
        { id: 200, image: "/images/product/img-13.svg" },
        { id: 201, image: "/images/product/small1.svg" },
        { id: 202, image: "/images/product/small2.svg" },
        { id: 203, image: "/images/product/small3.svg" },
        { id: 204, image: "/images/product/small4.svg" },
        { id: 205, image: "/images/product/small5.svg" },
        { id: 206, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
  ],
  returnOrders: [
    {
      id: 1,
      image: "/images/product/img-16.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "4",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_pickup: "20 July 2024",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      order_status: "Return",
      track_order: "XDYUS000058",
      total: "£10,000 ",
      return: true,
      return_order_track: [
        {
          id: 1,
          message: "Shipped",
          track_time: "Wednesday 7th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Delivered",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: true,
        },
      ],
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 4,
          message: "Return",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: false,
          return: true,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discountlabel: "",
      time: "",
      discount: "105100",
      original: "1790.00",
      save: "save $5",
      coupen: "with coupen",
      deliverytime: "Tuesday, Jul 16 – Saturday, Jul 20",
      freedelivery: "Free Delivery",
      bestseller: false,
      small: [
        { id: 100, image: "/images/product/img-16.svg" },
        { id: 101, image: "/images/product/small1.svg" },
        { id: 102, image: "/images/product/small2.svg" },
        { id: 103, image: "/images/product/small3.svg" },
        { id: 104, image: "/images/product/small4.svg" },
        { id: 105, image: "/images/product/small5.svg" },
        { id: 106, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
    {
      id: 2,
      image: "/images/product/img-13.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "3",
      discountlabel: "",
      time: "",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_pickup: "20 July 2024",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      order_status: "Return",
      track_order: "XDYUS000058",
      total: "£10,000 ",
      return: true,
      return_order_track: [
        {
          id: 1,
          message: "Shipped",
          track_time: "Wednesday 7th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Delivered",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: true,
        },
      ],
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 4,
          message: "Return",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: false,
          return: true,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discount: "105100",
      original: "1790.00",
      save: "",
      coupen: "",
      deliverytime: "Get it by Sunday, June 16",
      freedelivery: "FREE Delivery over $499.",
      bestseller: false,
      small: [
        { id: 200, image: "/images/product/img-13.svg" },
        { id: 201, image: "/images/product/small1.svg" },
        { id: 202, image: "/images/product/small2.svg" },
        { id: 203, image: "/images/product/small3.svg" },
        { id: 204, image: "/images/product/small4.svg" },
        { id: 205, image: "/images/product/small5.svg" },
        { id: 206, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
  ],
  cancelledOrders: [
    {
      id: 1,
      image: "/images/product/img-16.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "4",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      order_status: "Cancel",
      total: "£10,000 ",
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 4,
          message: "Cancel",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: false,
          cancel: true,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discountlabel: "",
      time: "",
      discount: "105100",
      original: "1790.00",
      save: "save $5",
      coupen: "with coupen",
      deliverytime: "Tuesday, Jul 16 – Saturday, Jul 20",
      freedelivery: "Free Delivery",
      bestseller: false,
      small: [
        { id: 100, image: "/images/product/img-16.svg" },
        { id: 101, image: "/images/product/small1.svg" },
        { id: 102, image: "/images/product/small2.svg" },
        { id: 103, image: "/images/product/small3.svg" },
        { id: 104, image: "/images/product/small4.svg" },
        { id: 105, image: "/images/product/small5.svg" },
        { id: 106, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
    {
      id: 2,
      image: "/images/product/img-13.svg",
      name: "APPUCOCO Mini Car Trash Bin Can Holder Dustbin - Black(L 17 x 6.5 cms)",
      rating: "3",
      discountlabel: "",
      time: "",
      review: "174",
      openReturnWindow: "25 July 2024",
      order_id: "402-0942907",
      order_shipping_user_name: "Mr. John Smith",
      address:
        "Street Address: 123 Fake StreetCity: LondonPost Town: Greater LondonPostal Code: SW1A 1AACountry: United Kingdom",
      phone_number: "+44 845625361",
      order_placed: "20 July 2024",
      delivery_date: "23 July",
      delivery_instructions: "Package was handed to resident",
      order_status: "Cancel",
      total: "£10,000 ",
      order_track: [
        {
          id: 1,
          message: "Order Confirmed",
          track_time: "Tuesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 2,
          message: "Shipped",
          track_time: "Wednesday 6th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 3,
          message: "Out For delivery",
          track_time: "Thursday 8th July 12:30 pm",
          started: true,
          done: true,
        },
        {
          id: 4,
          message: "Cancel",
          track_time: "Friday 9th July 12:30 pm",
          started: true,
          done: false,
          cancel: true,
        },
      ],
      detail_rating: [
        { id: 1, rate: 53, name: "5 star" },
        { id: 2, rate: 21, name: "4 star" },
        { id: 3, rate: 13, name: "3 star" },
        { id: 4, rate: 4, name: "2 star" },
        { id: 5, rate: 13, name: "1 star" },
      ],
      discount: "105100",
      original: "1790.00",
      save: "",
      coupen: "",
      deliverytime: "Get it by Sunday, June 16",
      freedelivery: "FREE Delivery over $499.",
      bestseller: false,
      small: [
        { id: 200, image: "/images/product/img-13.svg" },
        { id: 201, image: "/images/product/small1.svg" },
        { id: 202, image: "/images/product/small2.svg" },
        { id: 203, image: "/images/product/small3.svg" },
        { id: 204, image: "/images/product/small4.svg" },
        { id: 205, image: "/images/product/small5.svg" },
        { id: 206, image: "/images/product/small6.svg" },
      ],
      sizeList: [
        { id: 1, name: "S" },
        { id: 2, name: "M" },
        { id: 3, name: "L" },
        { id: 4, name: "XL" },
        { id: 5, name: "XXL" },
      ],
      gaurnteeMessage: [
        {
          id: 1,
          name: "Pay on Delivery",
          image: "/images/product/pay-delivery.svg",
        },
        {
          id: 2,
          name: "Free Delivery",
          image: "/images/product/free-delivery.svg",
        },
        {
          id: 3,
          name: "Return & Exchange",
          image: "/images/product/return-exchange.svg",
        },
        { id: 4, name: "Guaranteed", image: "/images/product/gaurntee.svg" },
      ],
      commitment: [
        { id: 1, name: "Safe payments" },
        { id: 2, name: "Secure privacy" },
        { id: 3, name: "15-day no update refund" },
        { id: 4, name: "Return if item damaged" },
        { id: 5, name: "20-day no delivery refund" },
        { id: 6, name: "24 x 7 Support" },
      ],
      availableOffers: [
        {
          id: 1,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
        {
          id: 2,
          name: "Get 5% Instant Discount on first on order of £200 and above ",
        },
      ],
      stocksLeft: "39",
      prdDetailDescription:
        "DIMENSIONS & CONTENTS: - One Elastic Fitted King Size Bedsheet with 2 Standard Size Pillow Covers.1 Double King Size Elastic Fitted Bedsheets Fits for 78 x 72 x 8 inches / 198 x 182 Cms / 6½ x 6 feet, Fits up to mattress thickness of 8 to 10 inch. Pillow Cover Size: Standard size 28 x 18 Inches. This fitted bedsheet is perfect for use in a home, hotel or ideal for any bedroom style. No more tucking of Bedsheets every morning. All-around elastic to pull in the borders to make it easily stretch and fit the base of the mattress.our fitted bedsheet features deep pockets and elasticized edges, ensuring a secure fit that stays in place throughout the night. VOMZER Fitted bed sheets are available in Multiple sizes and Vibrant colors which Enhances Room Decor. COTTON FEEL MATERIAL - Breathable Cotton Feel fabric brings a soft and cozy feel to your bed that tempts you to stay in bed for long, the 100% Premium fabric is lightweight, soft, and comfortable CARE INSTRUCTIONS: - Gentle Hand/Machine Wash in Coldwater, Use Mild detergent, Don’t Bleach, Wash Separately. Color may vary slightly from Photographic Images.",
      technical_details: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      additional_info: {
        os: "Android 13.0",
        ram: "128 GB",
        product_dimension: "16.4 x 7.6 x 0.9 cm; 189 g",
        batteries: "1 Lithium Polymer batteries",
        model: "BG7",
        wireless_com: "Cellular",
        connectivity: "Bluetooth, Wi-Fi, USB",
        special_feature:
          "Supports Usb Otg, Stereo Speakers, Front Camera With Flash, Dual_Sim, Water Resistant",
        device_interface: "Touchscreen",
      },
      customer_review: [
        {
          id: 1,
          name: "Flores, Juanita",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 2,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
        {
          id: 3,
          name: "Nguyen, Shane",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [],
        },
        {
          id: 4,
          name: "Miles, Esther",
          profile_image: "/images/blogs/blog-user.svg",
          rating: "5",
          rate_name: "Techno pova 5 pro",
          description:
            "Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini",
          product_review_image: [
            "/images/product-review.svg",
            "/images/product-review.svg",
            "/images/product-review.svg",
          ],
        },
      ],
      detailProductContent: [
        "/images/product/prd-detail1.svg",
        "/images/product/prd-detail2.svg",
        "/images/product/prd-detail3.svg",
        "/images/product/prd-detail4.svg",
        "/images/product/prd-detail1.svg",
      ],
    },
  ],
  availableCoupens: [
    {
      id: 1,
      title: "SAVE100",
      validity: "Validity 25July 2024",
      terms: "Term of use",
      conditions: [
        { id: 11, value: "Lorem Ipsum is simply dummy text of the printing." },
        {
          id: 12,
          value:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem I",
        },
      ],
    },
    {
      id: 2,
      title: "SAVE100",
      validity: "Validity 25July 2024",
      terms: "Term of use",
      conditions: [
        { id: 21, value: "Lorem Ipsum is simply dummy text of the printing." },
        {
          id: 22,
          value:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem I",
        },
      ],
    },
    {
      id: 3,
      title: "SAVE100",
      validity: "Validity 25July 2024",
      terms: "Term of use",
      conditions: [
        { id: 31, value: "Lorem Ipsum is simply dummy text of the printing." },
        {
          id: 32,
          value:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem I",
        },
      ],
    },
    {
      id: 4,
      title: "SAVE100",
      validity: "Validity 25July 2024",
      terms: "Term of use",
      conditions: [
        { id: 41, value: "Lorem Ipsum is simply dummy text of the printing." },
        {
          id: 42,
          value:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem I",
        },
      ],
    },
    {
      id: 5,
      title: "SAVE100",
      validity: "Validity 25July 2024",
      terms: "Term of use",
      conditions: [
        { id: 51, value: "Lorem Ipsum is simply dummy text of the printing." },
        {
          id: 52,
          value:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem I",
        },
      ],
    },
  ],
  reviewedProducts: [
    { id:1, prd_name: 'POCO M6 5G (Orion Blue, 8GB RAM, 256GB Storage)', order_no: '402-0942907', rating: 4, descriptipn: 'Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini ',
      prd_image: '/images/product/img-16.svg', date: '25July 2024 | 5 Pm ',
      prd_review_image: [
        {id:11, image: '/images/product/img-16.svg'},
        {id:12, image: '/images/product/img-16.svg'},
        {id:13, image: '/images/product/img-16.svg'},
      ]
    },
    { id:2, prd_name: 'POCO M6 5G (Orion Blue, 8GB RAM, 256GB Storage)', order_no: '402-0942907', rating: 5, descriptipn: 'Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini ',
      prd_image: '/images/product/img-16.svg', date: '25July 2024 | 5 Pm ',
      prd_review_image: [
        {id:21, image: '/images/product/img-16.svg'},
        {id:22, image: '/images/product/img-16.svg'},
        {id:23, image: '/images/product/img-16.svg'},
      ]
    },
    { id:3, prd_name: 'POCO M6 5G (Orion Blue, 8GB RAM, 256GB Storage)', order_no: '402-0942907', rating: 3, descriptipn: 'Aku cobain produk ini masih jaman sekolah, karna gak tau apa produk yg bagus. Dan alhamdulillah ini ',
      prd_image: '/images/product/img-16.svg', date: '25July 2024 | 5 Pm ',
      prd_review_image: [
        {id:31, image: '/images/product/img-16.svg'},
        {id:32, image: '/images/product/img-16.svg'},
        {id:33, image: '/images/product/img-16.svg'},
      ]
    }
  ]
};
